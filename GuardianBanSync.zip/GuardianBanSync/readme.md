Discord Ban Sync for FiveM

Overview

This resource automatically bans players from your FiveM server if they are banned from your Discord server. It checks a player's Discord ID when they try to join and removes them if they are banned. Additionally, it logs all ban attempts in a specified Discord channel, including the player's name, Discord ID, and IP address.

Features

Automatically bans players in FiveM if they are banned from the Discord server.

Logs ban attempts in a Discord channel.

Includes the player's name, Discord ID, and IP address in the logs.

Kicks players who do not have their Discord linked.

Installation Guide

1. Download and Install

Place the resource in your resources folder.

Add start bansync to your server.cfg.

2. Configure the Resource

Edit config.lua and set the following values:

Config = {}
Config.BotToken = "YOUR_BOT_TOKEN_HERE" -- Your Discord bot token
Config.GuildID = "YOUR_DISCORD_GUILD_ID" -- Your Discord server ID
Config.LogChannelID = "YOUR_LOG_CHANNEL_ID" -- The Discord channel where logs will be sent

3. Ensure Bot Permissions

The bot must have Ban Members permission in the Discord server.

The bot must have Send Messages permission in the log channel.

4. Restart Your Server

After configuring, restart your FiveM server to apply changes.

How It Works

When a player connects, the script checks their Discord ID.

If they are banned in Discord, they will be instantly removed from FiveM.

If banned, a log is sent to the specified Discord channel.

If their Discord is not linked, they will be denied entry.

Example Log in Discord

🚨 Ban Sync Alert 🚨
Player: RexZenn
Discord ID: 789948711714816002
IP Address: ||000.000.0.000||
Status: Tried to join but is banned from Discord!

Support

https://discord.gg/guardianlabs

If you encounter issues, ensure:

Your bot token and server IDs are correct in config.lua.

The bot has proper permissions in Discord.

The resource is properly started in server.cfg.

Enjoy secure and automated ban syncing for your FiveM server! 🚀

