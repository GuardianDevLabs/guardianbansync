fx_version 'cerulean'
game 'gta5'

author 'GuardianLabs'
description 'Discord Ban Sync - Made by GuardianLabs'
version '1.0.0'

server_scripts {
    'config.lua', -- Configuration File
    'server.lua'  -- Main Server Script
}